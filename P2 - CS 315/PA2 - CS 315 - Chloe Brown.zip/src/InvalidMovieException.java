/**
 * 
 */

/**
 * Simple Exception to handle invalid movies.  Doesn't really do anything besides being an exception.
 * 
 * @author Richard
 *
 */
public class InvalidMovieException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4496012944354433567L;

}
