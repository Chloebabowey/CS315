
/**
 * Simple Exception to handle invalid movies.  Doesn't really do anything besides being an exception.
 * 
 * @author Richard
 * Chloe Brown
 * Programming Assingment 1 - CS 315
 * October 5, 2017
 *
 */
public class InvalidMovieException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4496012944354433567L;

}
